export class User {
  id: number;
  username: string;
  password: string;
  city: string;
  phone: string;
  emailid: string;
  token: string;
}
